package cibernoid.multimedia.camara;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.provider.MediaStore;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.widget.ImageView;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import android.net.Uri;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    ImageView img;
    private Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img = (ImageView) findViewById(R.id.imageView);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirCamara();
                setContentView(R.layout.activity_main_2);
                img = (ImageView) findViewById(R.id.imageView);
            }
        });




    }

    public void abrirCamara(){
        //Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        //startActivityForResult(intent, 0);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        //File file = new File(Environment.getExternalStorageDirectory(), "nombredelarchivo.jpg");
        //File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
        //        Environment.DIRECTORY_PICTURES), "nombredelarchivo.jpg");
        //intent.putExtra(MediaStore.EXTRA_OUTPUT, mediaStorageDir);
        Uri uri  = Uri.parse("file:///sdcard/photo.jpg");
        intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri);
        startActivityForResult(intent, 0);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode,data);
        InputStream stream = null;
        if(requestCode==0 && requestCode ==RESULT_OK){
           try{
               if (bitmap != null){
                  bitmap.recycle();
               }

           stream = getContentResolver().openInputStream(data.getData());
           bitmap = BitmapFactory.decodeStream(stream);
           img.setImageBitmap(resizeImage(this, bitmap,700,600));

           }catch (FileNotFoundException e) {
               e.printStackTrace();
           }finally {
               if(stream != null){
                   try{
                       stream.close();
                   }catch(IOException e){
                       e.printStackTrace();
                   }

               }
           }

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }



    private static Bitmap resizeImage(Context context, Bitmap bmpOriginal, float newWidth, float newHeight){
        Bitmap nuevoBmp = null;
        int w = bmpOriginal.getWidth();
        int h = bmpOriginal.getHeight();

        float densityFactor = context.getResources().getDisplayMetrics().density;
        float nuevoW = newWidth * densityFactor;
        float nuevoH = newHeight * densityFactor;

        float scalaW = nuevoW/w;
        float scalaH = nuevoH/h;

        Matrix matrix = new Matrix();
        matrix.postScale(scalaW,scalaH);

        nuevoBmp = Bitmap.createBitmap(bmpOriginal, 0, 0, w, h, matrix, true);
        return nuevoBmp;


    }




}